let compras = ['Cenoura', 'Farinha', 'Fermento']
function adicionarProduto(produto){
    compras.push(produto)
    console.log(compras)
}
function removeproduto(produto){
    compras.pop(produto)
    console.log(compras)
}

adicionarProduto('Açúcar')
removeproduto()