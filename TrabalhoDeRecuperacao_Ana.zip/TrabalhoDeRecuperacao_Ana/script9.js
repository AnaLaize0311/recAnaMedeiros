let estudantes = ["Mateo", "Zuri", "Kiara", "Gublisqueldo"]
let maior10 = estudantes.find(num => num.length > 10)
console.log(maior10)