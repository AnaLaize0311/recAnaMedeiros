let indicacao = ['Anime1', 'Anime2', 'Anime3', 'Anime4']
let remocoes = 0
 function remover(){
    indicacao.pop()
    remocoes++
    if(remocoes === 3){
        indicacao.push('AnimeNovo')
        remocoes = 0
   }
    console.log('Recomendação ', indicacao)
}

remover()
remover()
remover()