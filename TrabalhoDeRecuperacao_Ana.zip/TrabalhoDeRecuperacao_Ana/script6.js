let alunos = ['Gabriel', 'Pedro', 'Tierre', 'Juarez']
let pos = alunos.indexOf('Gabriel')
alunos.splice(pos,1,'Vitor')
console.log(alunos)