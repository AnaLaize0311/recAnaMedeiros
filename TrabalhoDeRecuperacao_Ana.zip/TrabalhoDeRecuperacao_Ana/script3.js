let peca = ['Biela', 'Corta-vento', 'Cilindro']
    let first = peca.unshift('Pistão')
    peca.pop()
    console.log(peca)