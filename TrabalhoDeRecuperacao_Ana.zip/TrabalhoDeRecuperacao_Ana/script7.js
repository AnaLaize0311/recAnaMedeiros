let espera = ['P1', 'P2']
function novaPartida(){
    if (espera.length < 3) {
        espera.unshift('NovoJogador')
    }else{
        espera.shift()
    }
    console.log(espera)
}
novaPartida('P3')
novaPartida('P4')
novaPartida('P5')
novaPartida('P6')