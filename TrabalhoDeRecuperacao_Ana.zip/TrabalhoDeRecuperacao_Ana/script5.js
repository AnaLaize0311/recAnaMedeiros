let ListaEventos = ['7:00 - Acordar', '9:00 - Trabalhar', '12:00 - Reunião', '13:00 - Almoço']
let pos = ListaEventos.indexOf('13:00 - Almoço')
ListaEventos.splice(pos,1,'13:00 - Hora Extra')
console.log(ListaEventos)