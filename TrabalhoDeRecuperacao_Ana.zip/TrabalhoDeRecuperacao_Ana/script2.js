let comprador = ['Gabriel', 'Hamilton', 'Verstappen']
    let first = comprador.unshift('Schumacher')
    comprador.pop()
    console.log(comprador)