let livros = ["Gênessis", "Exôdo", "Levítico", "Numeros"]
let catalogo = livros.indexOf("Exôdo")
console.log(catalogo)
console.log(livros.indexOf("Jeremias"))